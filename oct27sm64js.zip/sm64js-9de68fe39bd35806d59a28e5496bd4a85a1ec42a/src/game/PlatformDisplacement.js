
class PlatformDisplacement {
    constructor() {
        this.gMarioPlatform = null
    }

    clear_mario_platform() { this.gMarioPlatform = null }
}

export const PlatformDisplacementInstance = new PlatformDisplacement()